<!DOCTYPE html>
<html>
<head>
	<title>MpesaTest</title>
</head>
<body>

	<form action="initiate.php" method="POST">
<div class="row">
  <div class="col-md-6">
  <div class="form-group">
    <label for="name">Full name</label>
    <input type="text" name="name" class="form-control" id="name" aria-describedby="name" placeholder="Enter Your name" required>
  </div>
  <div class="form-group">
    <label for="phone">Email address</label>
    <input type="phone" name="phone" class="form-control" id="phone" aria-describedby="phone" placeholder="Phone Number" required>
  </div>
  </div>
  <div class="col-md-6">
  
  
   

</div>
  <hr>
  <div class="row">
    <div class="col text-center">
      <button type="submit" class="btn btn-primary">Submit</button>
    </div>
  </div>
</form>

</body>
</html>